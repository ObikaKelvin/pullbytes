import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';

function Example() {

    const [licenses, setLicenses] = useState([]);

    const getInfo = async () => {
        const response = await axios.get('http://127.0.0.1:8000/api/v1/license');
        console.log(response);
        setLicenses(response.data);
    }
    
    useEffect(()=>{
        getInfo();
    }, 
    []);

    const displayLicenses = () => {
        return licenses.map(license => {
            return (
                <React.Fragment>
                    <div>{license.name}</div>
                    <div>{license.expire}</div>
                </React.Fragment>
            )
        })

    }

    

    if(licenses){
        return (
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-header">Welcome</div>

                            <div className="card-body">{displayLicenses()}</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="container">
           
        </div>
    )


}

export default Example;

if (document.getElementById('example')) {
    ReactDOM.render(<Example />, document.getElementById('example'));
}
