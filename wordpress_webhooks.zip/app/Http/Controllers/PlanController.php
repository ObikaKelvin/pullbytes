<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Http\Requests\PlanRequest;

use App\Models\Plan;
use Illuminate\Support\Str;
use Exception;

class PlanController extends Controller
{
    public function get_plans(){
        // try {
            //code...
            $plans = Plan::all();
            return response()->json([
                'status' => 'success',
                'plans' => $plans
            ], 200);
        // } catch (\Throwable $th) {
        //     //throw $th;
        //     return response()->json($th, 404);
        // }
    }

    public function create_plan(PlanRequest $request){

        try {
            //code...
            $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
            $plan = new Plan([
                'name' => $request->input('name'),
                'can_expire' => $request->input('can_expire'),
                'active_url_number' => $request->input('active_url_number'),
                'price' => $request->input('price'),
                'duration' => $request->input('duration'),
                'description' => $request->input('description'),
                'features' => json_encode($request->input('features')),
            ]);
            
            // try {
            //     //code...               
            //     $stripe_product = $stripe->products->create([
            //     'name' => $plan->name,
            //     'description' => $request->input('description'),
            //     ]);

            //     try {
            //         //code...
            //         $stripe_price = $stripe->prices->create([
            //             'unit_amount' => $plan->price,
            //             'currency' => 'usd',
            //             'recurring' => ['interval' => 'year'],
            //             'product' => $stripe_product->id,
            //         ]);

            //         $plan->save();
            //     } catch (\Throwable $th) {
            //         return response()->json($th->getMessage(), 400);
            //     }

            // } catch (\Throwable $th) {
            //     //throw $th;
            //     return response()->json($th->getMessage(), 400);
            // }
            
            $plan->save();

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json($th->getMessage(), 400);
        }

        return response()->json($plan, 201);

    }

    public function get_plan($id){
        try {
            //code...
            $plan = Plan::find($id);
            // if(!$plan){
            //     throw new Exception("plan was not found");
            // }
            return response()->json($plan, 200);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json($th->getMessage(), 404);
        }
    }

    public function update_plan($id, Request $request){
        try {
            //code...
            $plan = Plan::find($id);
            if(!$plan){
                throw new Exception("plan was not found");
            }
            $plan->name = $request->input('name');
            $plan->price = $request->input('price');
            $plan->description = $request->input('description');
            $plan->can_expire = $request->input('can_expire');
            $plan->save();
            return response()->json([
                'status' => 'success',
                'plan' => $plan
            ], 204);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json($th->getMessage(), 404);
        }
    }

    public function delete_plan($id){
        try {
            //code...
            $plan = Plan::find($id);
            if(!$plan){
                throw new Exception("plan was not found");
            }
            $plan->delete();
            return response()->json(null, 204);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json($th->getMessage(), 404);
        }
    }
}
