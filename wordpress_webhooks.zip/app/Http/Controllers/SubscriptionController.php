<?php

namespace App\Http\Controllers;

use Laravel\Cashier\Subscription as Subscription;
use App\Models\Plan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Cashier\Cashier;

class SubscriptionController extends Controller
{
    public function getSubscriptions()
    {
        $subscriptions = Subscription::all();
        return response()->json(
            [
                'status' => 'success',
                'subscriptions' => $subscriptions
            ], 
        200);
    }
    
    public function getSubscription()
    {
        $user = Auth::user();
        $subscriptions = Subscription::all();
        if($user->subscribed()){
            return response()->json(
                [
                    'status' => 'success',
                    'message' => "subscribed"
                ], 
            200);
        }

        return response()->json(
            [
                'status' => 'success',
                'subscriptions' => $subscriptions
            ], 
        200);
    }

    public function getStripeIntent()
    {
        $user = Auth::user();
        $intent = $user->createSetupIntent();
        return response()->json(
            [
                'status' => 'success',
                'intent' => $intent->secret
            ], 
        200);
    }

    public function createSubscription(Request $request, $planId)
    {
    
        try {
            $user = Auth::user();
            $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
            $plan = Plan::find($planId);
                    
            if(!$user->stripe_id){
                $stripeCustomer = $user->createAsStripeCustomer();
            }
            $stripeCustomer = Cashier::findBillable($user->stripe_id);
            
            $payment_method = $stripeCustomer->defaultPaymentMethod();

            $card_token = $stripe->tokens->create([
                'card' => $request->card,
            ]);

            $customer_card = $stripe->customers->createSource(
                $user->stripe_id,
                ['source' => $card_token]
            );
            
            // if(!$user->hasPaymentMethod()){
            //     $card_token = $stripe->tokens->create([
            //         'card' => $request->card,
            //     ]);
                
            //     $customer_card = $stripe->customers->createSource(
            //         $user->stripe_id,
            //         ['source' => $card_token]
            //     );
                
            // }
            // $intent = $user->createSetupIntent(
            //     [ 'customer' => $user->stripe_id ]
            // );

            // $confirmed_intent = $stripe->setupIntents->confirm(
            //     $intent->id,
            //     ['payment_method' => $customer_card]
            // );

            // $payment_method = $confirmed_intent->payment_method;

            // if(!$user->subscribed()){
            //     $user->newSubscription(
            //         '5 sites classic', 'price_1IQGfLHxFZiZPKLwIOh7AGSw'
            //     )->create($payment_method);
            // }

            $products = $stripe->prices->all(['product' => 'prod_J2JGBNPLqi8MUb']);

            $payment_methods = [];

            foreach($stripeCustomer->paymentMethods() as $payment_method){
                $payment_methods[] = $payment_method->asStripePaymentMethod();
            }

            return response()->json(
                [
                    'status' => 'success',
                   'products'=>$payment_methods
                    // 'messag' => $customer_card,
                    // 'message' => $payment_methods,
                ], 
            200);

        } catch (\Throwable $th) {
            return response()->json(
                [
                    'status' => 'fail',
                    // 'message' => "Sorry, can not process payment now",
                    'message' => $th->getMessage()
                ], 
            200);
        }
    }

    public function cancel_renewal()
    {
        $user = Auth::user();
        if($user->subscription('')){};
    }
}
