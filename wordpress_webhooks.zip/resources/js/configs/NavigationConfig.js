import { 
  DashboardOutlined,
  UserSwitchOutlined,
  ShoppingOutlined,
  TagOutlined,
  BookOutlined,
} from '@ant-design/icons';
import { APP_PREFIX_PATH } from 'configs/AppConfig'

const dashBoardNavTree = [
  {
    key: 'home',
    path: `${APP_PREFIX_PATH}/admin/home`,
    title: 'home',
    icon: DashboardOutlined,
    breadcrumb: false,
    submenu: []
  },
  {
    key: 'plans',
    path: `${APP_PREFIX_PATH}/admin/plans`,
    title: 'plans',
    icon: BookOutlined,
    breadcrumb: false,
    submenu: []
  },
  {
    key: 'licenses',
    path: `${APP_PREFIX_PATH}/admin/licenses`,
    title: 'licenses',
    icon: TagOutlined,
    breadcrumb: false,
    submenu: []
  },
  {
    key: 'users',
    path: `${APP_PREFIX_PATH}/admin/users`,
    title: 'Users',
    icon: UserSwitchOutlined,
    breadcrumb: false,
    submenu: []
  },
  {
    key: 'subscriptions',
    path: `${APP_PREFIX_PATH}/admin/subscriptions`,
    title: 'Subscriptions',
    icon: ShoppingOutlined,
    breadcrumb: false,
    submenu: []
  },
  {
    key: 'profile',
    path: `${APP_PREFIX_PATH}/admin/profile`,
    title: 'Profile',
    icon: DashboardOutlined,
    breadcrumb: false,
    submenu: []
  }
]

const navigationConfig = [
  ...dashBoardNavTree
]

export default navigationConfig;
