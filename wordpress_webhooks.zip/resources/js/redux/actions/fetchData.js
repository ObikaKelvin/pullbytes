import {
	GET_PLANS,
	GET_ME,
	GET_USERS,
	GET_LICENSES,
	GET_SUBSCRIPTIONS
} from '../constants/Actions';

export const getPlans = (resp) => {
    return {
        type: GET_PLANS,
        payload: resp
    }
}

export const getUsers = (users) => {
    return {
        type: GET_USERS,
        payload: users
    }
}

export const getMe = (user) => {
    return {
        type: GET_ME,
        payload: user
    }
}

export const getLicenses = (licenses) => {
    return {
        type: GET_LICENSES,
        payload: licenses
    }
}

export const getSubscriptions = (subscriptions) => {
    return {
        type: GET_SUBSCRIPTIONS,
        payload: subscriptions
    }
}