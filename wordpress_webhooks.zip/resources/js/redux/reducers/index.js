import { combineReducers } from 'redux';
import Auth from './Auth';
import Theme from './Theme';
import PlanReducer from './PlanReducer';
import UserReducer from './UserReducer';
import LicenseReducer from './LicenseReducer';
import SubscriptionReducer from './SubscriptionReducer';

const reducers = combineReducers({
    theme: Theme,
    auth: Auth,
    planReducer: PlanReducer,
    userReducer: UserReducer,
    licenseReducer: LicenseReducer,
    subscriptionReducer: SubscriptionReducer
});

export default reducers;