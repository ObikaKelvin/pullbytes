import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Example from 'components/Example.js';

function Keiks() {

    return (
        <div className="container">
           <Example/>
        </div>
    )


}

export default Keiks;

