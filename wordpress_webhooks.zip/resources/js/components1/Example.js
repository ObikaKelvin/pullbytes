import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';

function Example() {

    const [data, setData] = useState([]);

    const getInfo = async () => {
        const response = await axios.get('http://127.0.0.1:8000/api/v1/data');
        console.log(response.data[0].name);
        setData(response.data[0]);
    }
    
    useEffect(()=>{
        getInfo();
    }, 
    []);

    

    if(data){
        return (
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-header">Welcome {data.name}</div>
    
                            <div className="card-body">I'm an keiks component!</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="container">
           
        </div>
    )


}

export default Example;

if (document.getElementById('example')) {
    ReactDOM.render(<Example />, document.getElementById('example'));
}
