import React, { lazy, Suspense, useState, useEffect } from "react";
import { Switch, Route, Redirect, useHistory } from "react-router-dom";
import { connect } from "react-redux";
import Loading from 'components/shared-components/Loading';
import { APP_PREFIX_PATH } from 'configs/AppConfig'
import { AUTH_PREFIX_PATH } from 'configs/AppConfig'
import isAdmin from '../../components/hoc/isAdmin'
import { AUTH_TOKEN } from '@redux/constants/Auth'
import DataService from '../../services/DataService'


export const AppViews = (props) => {

  const [path, setPath] = useState('');
  const [authUser, setAuthUser] = useState('');

  const jwtToken = localStorage.getItem(AUTH_TOKEN)
  const history = useHistory();

  if(!jwtToken){
    history.push(`/auth/login`);
  }

  const role = async () => {
    
    const response = await DataService.me();
    const user = response.user;
    setAuthUser(user);
    setPath(user.role === 'admin' ? 'admin' : 'user');
  }

  useEffect(() => {
    // role()
  }, [])

  
  return (
    <Suspense fallback={<Loading cover="content"/>}>
      <Switch>
        <Route path={`${APP_PREFIX_PATH}/admin`} component={lazy(() => import(`./admin-views`))} />
        <Route path={`${APP_PREFIX_PATH}/user`} component={lazy(() => import(`./user-views`))} />

        {/* {path && <Redirect from={`${APP_PREFIX_PATH}`} to={`${APP_PREFIX_PATH}/${path}`} />} */}
        <Redirect from={`${APP_PREFIX_PATH}`} to={`${APP_PREFIX_PATH}/admin`} />
      </Switch>
    </Suspense>
  )
}


export default React.memo(connect(null, null)(AppViews));