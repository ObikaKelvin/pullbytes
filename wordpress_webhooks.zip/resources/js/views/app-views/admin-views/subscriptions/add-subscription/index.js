import React from 'react';
import SubscriptionForm from '../SubscriptionForm';

const Subscription = () => {
	return (
		<SubscriptionForm mode="ADD"/>
	)
}

export default Subscription
