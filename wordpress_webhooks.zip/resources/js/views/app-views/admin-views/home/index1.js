import React from 'react'

const Home1 = () => {
	return (
		<div>
			Home component works!
		</div>
	)
}

export default Home1
