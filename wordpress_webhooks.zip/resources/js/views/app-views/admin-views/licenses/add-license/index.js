import React from 'react';
import LicenseForm from '../LicenseForm';

const AddUser = () => {
	return (
		<LicenseForm mode="ADD"/>
	)
}

export default AddUser
