import React from 'react'
import { Input, Row, Col, Card, Form, Upload, InputNumber, message, Select } from 'antd';
import { ImageSvg } from 'assets/svg/icon';
import CustomIcon from 'components/util-components/CustomIcon'
import { LoadingOutlined } from '@ant-design/icons';

const { Dragger } = Upload;
const { Option } = Select;

const rules = {
	name: [
		{
			required: true,
			message: 'Please enter a name',
		}
	],
	description: [
		{
			required: true,
			message: 'Please enter a description',
		}
	],
	price: [
		{
			required: true,
			message: 'Please enter a price',
		}
	]
}

const categories = ['Cloths', 'Bags', 'Shoes', 'Watches', 'Devices']
const tags = ['Cotton', 'Nike', 'Sales', 'Sports', 'Outdoor', 'Toys', 'Hobbies' ]

const GeneralField = props => (
	<Row gutter={16}>
		<Col xs={24} sm={24} md={17}>
			<Card title="Basic Info">
				<Form.Item name="name" label="Name" rules={rules.name}>
					<Input placeholder="Name" />
				</Form.Item>
				<Form.Item name="price" label="price" rules={rules.price}>
					<InputNumber
						className="w-100"
						formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
						parser={value => value.replace(/\$\s?|(,*)/g, '')}
					/>
				</Form.Item>
				<Form.Item name="description" label="Description" rules={rules.description}>
					<Input.TextArea rows={4} />
				</Form.Item>
			</Card>
		</Col>
		<Col xs={24} sm={24} md={7}>
			<Card title="Organization">
				<Form.Item name="can_expire" label="Can expire" >
					<Select className="w-100" placeholder="Can expire">
						<Option key="yes" value="yes">Yes</Option>
						<Option key="no" value="no">No</Option>
					</Select>
				</Form.Item>
				<Form.Item name="tags" label="Tags" >
				<Select mode="tags" style={{ width: '100%' }} placeholder="Tags">
					{tags.map(elm => <Option key={elm}>{elm}</Option>)}
				</Select>
				</Form.Item>
			</Card>
		</Col>
	</Row>
)

export default GeneralField
