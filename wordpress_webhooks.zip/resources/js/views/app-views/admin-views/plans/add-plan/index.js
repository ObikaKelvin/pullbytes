import React from 'react';
import ProductForm from '../PlanForm';

const AddPlan = () => {
	console.log('add product page');
	return (
		<ProductForm mode="ADD"/>
		// <div>add product page</div>
	)
}

export default AddPlan
