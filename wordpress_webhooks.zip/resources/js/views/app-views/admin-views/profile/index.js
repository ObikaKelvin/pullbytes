import React from 'react'

const Profile = () => {
	return (
		<div>
			Profile component works!
		</div>
	)
}

export default Profile
