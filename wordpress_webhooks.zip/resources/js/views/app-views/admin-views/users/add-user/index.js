import React from 'react';
import UserForm from '../UserForm';

const AddUser = () => {
	return (
		<UserForm mode="ADD"/>
	)
}

export default AddUser
