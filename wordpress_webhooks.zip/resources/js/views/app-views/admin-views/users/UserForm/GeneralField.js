import React from 'react'
import { Input, Row, Col, Card, Form, Upload, InputNumber, message, Select } from 'antd';
import { ImageSvg } from 'assets/svg/icon';
import CustomIcon from 'components/util-components/CustomIcon'
import { LoadingOutlined } from '@ant-design/icons';

const { Option } = Select;

const rules = {
	name: [
		{
			required: true,
			message: 'Please enter name',
		}
	],
	email: [
		{
			required: true,
			message: 'Please enter email address',
		}
	],
	role: [
		{
			required: true,
			message: 'Please select role',
		}
	]
}

const GeneralField = props => (
	<Row gutter={16}>
		<Col xs={24} sm={24} md={18}>
			<Card title="Basic Info">
				<Form.Item name="name" label="Name" rules={rules.name}>
					<Input placeholder="Name" />
				</Form.Item>
				<Form.Item name="email" label="email" rules={rules.email}>
				<Input placeholder="Email Address" />
				</Form.Item>
				<Form.Item name="role" label="Role" >
					<Select className="w-100" placeholder="Role">
						<Option key="customer" value="customer">Customer</Option>
						<Option key="admin" value="admin">Admin</Option>
					</Select>
				</Form.Item>
			</Card>
		</Col>
		
	</Row>
)

export default GeneralField
