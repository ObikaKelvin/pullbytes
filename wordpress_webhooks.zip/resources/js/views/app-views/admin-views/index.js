import React, { lazy, Suspense } from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { APP_PREFIX_PATH } from 'configs/AppConfig'

import Loading from 'components/shared-components/Loading';


const AdminViews = (props) => {
    const { match } = props;
    return (

		<Suspense fallback={<Loading cover="content"/>}>
			<Switch>
				<Redirect exact from={`${match.url}`} to={`${match.url}/home`} />
				{/* <Route path={`${match.url}`} component={Home} /> */}
				
				<Route path={`${match.url}/home`} component={lazy(() => import(`./home`))} />
				<Route path={`${match.url}/plans`} component={lazy(() => import(`./plans`))} />
				<Route path={`${match.url}/users`} component={lazy(() => import(`./users`))} />
				<Route path={`${match.url}/licenses`} component={lazy(() => import(`./licenses`))} />
				<Route path={`${match.url}/subscriptions`} component={lazy(() => import(`./subscriptions`))} />
				{/* <Route path={`${match.url}/profile`} component={lazy(() => import(`./admin-views/profile`))} /> */}
			</Switch>
		</Suspense>
	)
} 

export default AdminViews;