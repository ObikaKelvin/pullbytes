import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';



const UserViews = (props) => {
    const { match } = props;

    return (
		<Switch>
			<Redirect exact from={`${match.url}`} to={`${match.url}/home`} />
			
		</Switch>
	)
} 

export default UserViews;